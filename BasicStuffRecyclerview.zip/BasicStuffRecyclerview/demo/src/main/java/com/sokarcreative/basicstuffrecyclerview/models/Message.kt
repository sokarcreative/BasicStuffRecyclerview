package com.sokarcreative.basicstuffrecyclerview.models

/**
 * Created by sokarcreative on 06/10/2017.
 */

class Message(val author: String, val message: String)
